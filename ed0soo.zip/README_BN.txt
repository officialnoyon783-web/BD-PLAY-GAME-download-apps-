BD FIRE GAME — Source Starter ZIP

এটি BD FIRE GAME-এর সোর্স প্রজেক্টের শুরু করার প্যাকেজ; এটি সম্পূর্ণ Free Fire-মানের গেম বা প্রস্তুত APK নয়।

চালানোর জন্য:
1) কম্পিউটারে Node.js 20+ ইনস্টল করুন।
2) server ফোল্ডারে টার্মিনাল খুলে: npm install
3) তারপর: npm start
4) ব্রাউজারে client/index.html খুলুন।

গুরুত্বপূর্ণ:
- এখনকার প্যাকেজে 3D client scaffold এবং WebSocket server-এর প্রাথমিক room/lobby সংযোগ আছে।
- এখনো আসল 3D চরিত্র/অস্ত্রের মডেল, combat, matchmaking, account login, anti-cheat, database, payment/diamond system, production hosting এবং Android APK build যোগ করা হয়নি।
- এই ZIP একা Aura FFX-এ আপলোড করলেই পূর্ণ অনলাইন গেম বা APK হবে না।
- Free Fire-এর নাম, লোগো, ম্যাপ, চরিত্র বা সম্পদ কপি করা হয়নি।
