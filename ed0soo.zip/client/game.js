// BD FIRE GAME client foundation — Babylon.js
const canvas = document.getElementById("renderCanvas");
const statusEl = document.getElementById("status");
const engine = new BABYLON.Engine(canvas, true);
const scene = new BABYLON.Scene(engine);
scene.clearColor = new BABYLON.Color4(0.42, 0.68, 0.82, 1);

const camera = new BABYLON.ArcRotateCamera("camera", -Math.PI/2, 1.1, 18,
  new BABYLON.Vector3(0, 1, 0), scene);
camera.attachControl(canvas, true);
camera.lowerRadiusLimit = 7;
camera.upperRadiusLimit = 28;

const light = new BABYLON.HemisphericLight("sun", new BABYLON.Vector3(0,1,0), scene);
light.intensity = 0.9;

const ground = BABYLON.MeshBuilder.CreateGround("ground",
  {width:100, height:100}, scene);
const groundMat = new BABYLON.StandardMaterial("groundMat", scene);
groundMat.diffuseColor = new BABYLON.Color3(0.23,0.42,0.25);
ground.material = groundMat;

const player = BABYLON.MeshBuilder.CreateCapsule("player",
  {height:2, radius:0.45}, scene);
player.position.y = 1;
const playerMat = new BABYLON.StandardMaterial("playerMat", scene);
playerMat.diffuseColor = new BABYLON.Color3(0.15,0.55,0.95);
player.material = playerMat;
camera.target = player.position;

for (let i=0;i<24;i++) {
  const x = (Math.random()-0.5)*80, z = (Math.random()-0.5)*80;
  const tree = BABYLON.MeshBuilder.CreateCylinder("tree"+i,
    {height:4, diameter:1.1}, scene);
  tree.position.set(x,2,z);
  const m = new BABYLON.StandardMaterial("treeMat"+i,scene);
  m.diffuseColor = new BABYLON.Color3(0.12,0.34,0.13);
  tree.material=m;
}

const keys = {};
window.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
window.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);
scene.onBeforeRenderObservable.add(() => {
  const speed = 0.12;
  if(keys.w || keys.arrowup) player.position.z += speed;
  if(keys.s || keys.arrowdown) player.position.z -= speed;
  if(keys.a || keys.arrowleft) player.position.x -= speed;
  if(keys.d || keys.arrowright) player.position.x += speed;
  camera.target.copyFrom(player.position);
});
engine.runRenderLoop(() => scene.render());
window.addEventListener("resize", () => engine.resize());

// Connect to local starter server. For deployment, configure a secure public WSS URL.
const socket = new WebSocket("ws://localhost:8080");
socket.onopen = () => {
  statusEl.textContent = "সার্ভার সংযুক্ত — Starter Lobby";
  socket.send(JSON.stringify({type:"join", name:"Guest"}));
};
socket.onmessage = e => {
  try {
    const msg = JSON.parse(e.data);
    if (msg.type === "welcome") statusEl.textContent = "Lobby-তে যুক্ত: " + msg.id;
    if (msg.type === "players") statusEl.textContent = "Lobby players: " + msg.count;
  } catch {}
};
socket.onerror = () => statusEl.textContent = "সার্ভার পাওয়া যায়নি — আগে server চালু করুন";
socket.onclose = () => statusEl.textContent = "সার্ভার সংযোগ বন্ধ";
