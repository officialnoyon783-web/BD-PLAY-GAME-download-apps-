const WebSocket = require("ws");
const { randomUUID } = require("crypto");
const wss = new WebSocket.Server({ port: 8080 });
const clients = new Map();

function broadcastPlayers() {
  const payload = JSON.stringify({ type: "players", count: clients.size });
  for (const ws of clients.keys()) {
    if (ws.readyState === WebSocket.OPEN) ws.send(payload);
  }
}

wss.on("connection", ws => {
  const id = randomUUID().slice(0, 8);
  clients.set(ws, { id, name: "Guest" });
  ws.send(JSON.stringify({ type: "welcome", id }));
  broadcastPlayers();

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === "join" && typeof msg.name === "string") {
      clients.get(ws).name = msg.name.slice(0, 20);
      broadcastPlayers();
    }
  });

  ws.on("close", () => {
    clients.delete(ws);
    broadcastPlayers();
  });
});
console.log("BD FIRE GAME lobby server listening on ws://localhost:8080");
